# tmvoucher2

Created time: December 10, 2023 4:05 PM

An existing member of team marc saw my advert in facebook for selling a digital product like voucher and one example is 500 pesos voucher with a very pleasing graphics. The customer then selected it and put in the cart and on the payment you can select to pay phpt or peso. As i have integrated api of both payment along with the api of casino. Now im thinking of recreating in a very flexible way similar to a headless cms that i can call and integrate anywhere. To provide you more context. I will give you an example of the selected api that is needed for this scenario.

Assuming that customer already bought the voucher using peso and pay on my integrated payment gateway which is gocashflex. The flow will be as follows.

1. An interactive single page containing the graphics or the voucher. At the back of the voucher there is a sort of scratch that the user will try to scratch it and it will reveal a qr that when you try to use another phone will redirect to another page or it has also an option to reveal the code so the user can simply copy and paste it, on the code reveal the same link I mentioned on the qr is embeded in that code so when pressed the. Will redirect to the url.
2. On the next page a sleek professional design page is going to show a form that the customer needs to enter its username. Since this is exclusive for team marc members only (agents/players) then to validate the username. An Api call is needed here to check its hierarchy and to check which top manager it belongs to. I have three accounts and each of them has separate token needed in api call to the casino platform so it is vital to identify which correct top manager the user belongs to to be able to let the logic function decide which account to be used and fetched its corresponding token. As mentioned abount the 3 accounts and tokens then here is the list of the information below:
- Bossmarc@747	69aa9bb1-62a1-4c3a-b044-33aaec67a8fe
- Teammarc	994111a6-4edc-45a6-b0b3-629ef9fe7ea4
- Marcthepogi	e5aeeb98-d795-4410-89e8-297ad2810852

Next on the following list below are the API needed to use:

1. (Tmpay747 is another third party api to handle member verification) Getuser Api: this api will provide a complete details of the username input (example: userrole, top manager, immidiate manager, balance, statistics and etc). On our ise case here for voucher, the importance of this api is to determine its top manager and to validate that the user belongs to my team, otherwise even if the player bought the voucher and not validated as team marc member then the casino will reject the api call as not allowed.
2. (Paygram) issueInvoice API: this serves as the api to make the payment using telegram paybot, so when this api is called then the response will return a payurl which then when you clicked or open in a browser then its going to open telegram and you will be redirected to the paybot named paygram (@opgmbot) and since the amount is already predefined so the paybot will only show a menu to pay that when the user clicked then the last Api call will trigger which is the actual deposit of chips on the input username account with the predefined amount that is generally from the voucher idea.
3. (Casino) Deposit API : this is where the long journey ending happily ever after. So upon successful payment then this api will be triggerred and will deposit the pre given amount. And a popup should show and a message with sonething that the voucher is used and account deposited with that amount etc and there is a button that when clicked then will redirect to the players gaming portal of 747 live.
4. I also have one API that might be needed, its a message API of casino that will send a message to a username that you will enter on the parameter post body that will go to the inbox of the user on the actual casino site.

Next is the curl commands along with the responses of the API that I mentioned above.

1. Getuser hierarchy Api call (on this demo lets give an example of a player with a username: wakay and the player bought 100 pesos worth of voucher). And here is the curl command and the actual response

curl -X GET 'https://tmpay747.azurewebsites.net/api/bridge/get-user/wakay/false' -H 'accept:*/*'

Response: {

"clientId": 329777805,

"isAgent": false,

"userType": "Player",

"username": "Wakay",

"topManager": "Marcthepogi",

"immediateManager": "platalyn@gmail.com",

"statistic": {

"currentBalance": 4.56,

"statisticsForThePast7Days": {

"totalDeposit": 37810,

"totalBet": 159649,

"totalWithdraw": 5000,

"canWithdraw": true,

"amountToBet": 0,

"wageringFactor": 4.222401481089658

},

"statisticsForMostRecentDeposit": {

"totalDeposit": 5000,

"totalBet": 10960,

"totalWithdraw": 0,

"canWithdraw": true,

"amountToBet": 0,

"wageringFactor": 2.192

},

"status": 0,

"message": "OK"

},

"turnOver": null,

"managers": [

"platalyn@gmail.com",

"Wakay"

]

}

Here we found that wakay belongs to marcthepogi as top manager which means it belongs to my team based on the response data(“top manager : Marcthepogi”). I already mentioned and provided the token of each top manager which is needed for authenticating Casino Api call for deposit.

Please note that my next api call is for payment which is the second API is not going to use the token because those tokens you stored is for casino api and my next api is for the telegram paybot to make the payments. So i am expecting that you will refine this response by putting this new fields: 1. Ismember=true or false where if you can find any of the 3 usernames then it is true else false and if true then only proceed in the next api that i will provide.

1. Paygram issueInvoice api: curl -X GET 'https://tgin.pay-gram.org/PayGramUsers/8YVgoWU7u4gmABVwJyetBL8vLaaz3e91FevPUNW4rhm7R50IYK0MsBGyrv78SW7B4yZqmFLbOJkbbVvXJN6F63ewzdZjsKX4mnoFQ5Sbqfw62tA4D8X7tnKg7yYoYVph8iAxStvCWDXNhWNwOlZLe6MHg7yOdEex5ASByWgXzTFQZptbcyvrkWl7oUgEhkvisxeXFInTxUtXeLAzwdJX0mrXHY6m44vc4lR3JjwPPxFQEXfAWaTIWDuymCGrcq6F/IssueInvoice?amt=10&cursym=11&callbackData=https://marc747.com/api/DepositCallbackRequest/PayGramDepCallBackReqAsync',

sample response

{

"payUrl": "https://telegram.me/opgmbot?start=YT1pJmM9ZjAwZGMzZWItNDQ1MS00NzJlLTgyY2EtYmU1MjI5YWY2MWE4",

"invoiceCode": "f00dc3eb-4451-472e-82ca-be5229af61a8",

"status": 4,

"lastEventUtc": "2023-11-27T06:27:37.7026656Z",

"createdUtc": "2023-11-27T06:27:37.7026654Z",

"amount": 100,

"expectedFee": 0,

"callbackData": "https://marc747.com/api/DepositCallbackRequest/PayGramDepCallBackReqAsync",

"currencyCode": 11,

"fromUser": null,

"toUser": "1104423387",

"originatingUser": null,

"isPaid": false,

"isRedeemed": false,

"invoiceType": 0,

"message": "ResponseOK",

"type": 14,

"responseCode": 200,

"success": true

}

1. I suggest that the implementation to handle the redirection of the user to telegram to make the payment should create a separate function that will extract the payurl and to embed on a button click.
2. Then on this part the function to handle the realtime update of succesful payment should come then next is the casino deposit
3. Depositchips api (747bridge): curl -X POST 'https://bridge.747lc.com/Default/Transfer' -H 'accept:text/plain' -H 'Content-Type:application/json' -d '{

"authToken": "994111a6-4edc-45a6-b0b3-629ef9fe7ea4",

"platform": 1,

"amount": 10o,

"toAgent": false,

"currency": "php",

"nonce": "1278",

"username": "wakay",

"comment": "test for callback"

}'

{

"status": 0,

"message": "ok"

}

1. Sendmessage api (747bridge) mybe we can use this as security geatures in a form of otp where we can be sure tgat tge one who do transact will receive a message on its account inbox in the casino platform. Suggest which area on kur flow to have this. curl -X POST 'https://bridge.747lc.com/Default/SendMessage' -H 'accept:text/plain' -H 'Content-Type:application/json' -d '{

"authToken": "e5aeeb98-d795-4410-89e8-297ad2810852",

"platform": 1,

"username": "platalyn@gmail.com",

"subject": "password",

"message": "use this password: j5k4g4 "

}'

Response: {

"status": 0,

"message": null

}